//2) En Linea con Fragment. 

//La usamos cuando deseamos renderizar un elemento condicional en función de una expresión booleana. 

const TecnicaDos = ({ booleado }) => {
  return (
    <>  
        {booleado && <h2> Usuario Registrado </h2>}
        {!booleado && <h2>Usuario NO REGISTRADO </h2>}

    </>
  )
}

export default TecnicaDos