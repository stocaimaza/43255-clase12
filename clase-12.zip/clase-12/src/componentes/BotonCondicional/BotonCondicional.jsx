import { useState } from "react"


const BotonCondicional = () => {
    const [verificado, setVerificado] = useState(false);
    //Creo algunos estados para el usuario y contraseña:
    const [usuario, setUsuario] = useState("");
    const [pass, setPass] = useState("");

    const habilitarUsuario = (e) => {
        e.preventDefault();

        //Implemento la lógica de validación:
        if( usuario === "Tinki" && pass === "Winki") {
            setVerificado(true);
        } else {
            setUsuario("Ladrón!!");
            setPass("Vete Malvado!!!");
        }
    }

    const deshabilitarUsuario = () => {
        setVerificado(false);
    }

  return (
    <>
        { verificado ? (<button onClick={deshabilitarUsuario}> Cerrar Sesión </button>): (
            <form onSubmit={habilitarUsuario}>
                <label htmlFor="usuario"> Usuario </label>
                <input type="text" id="usuario" value={usuario} onChange={(e)=> setUsuario(e.target.value)} />


                <label htmlFor="pass"> Contraseña </label>
                <input type="text" id="pass" value={pass} onChange={(e)=> setPass(e.target.value)} />

                <button> Iniciar Sesión </button>

            </form>
        )} 
    
    
    
    </>
  )
}

export default BotonCondicional