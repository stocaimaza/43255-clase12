//1) Return Temprano: 

//Esta técnica a usamos en JS y evitamos colocar el ELSE. 

//Ejemplo: función booleana que me dice si es fin de semana. 

function esFinDe(dia) {
    if(dia === "sabado" || dia === "domingo") {
        return true;
    } else {
        return false;
    }
}

//Peeeeeeeeeeeero si aplico la regla del retorno temprano: 

function esFinDeSemana(dia) {
    if(dia === "sabado" || dia === "domingo") {
        return true;
    }
    return false; 
}


//PASAMOS ESTA TÉCNICA A REACT: 


const TecnicaUno = ({nombre}) => {
    if(nombre === "Samuel") {
        return <h1> Hola Administrador! </h1>
    }
  return (
    <div> 
        <h2>Hola {nombre}</h2>
    </div>
  )
}

export default TecnicaUno